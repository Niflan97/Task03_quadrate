namespace WebApplication4.Models
{
    public class Contacts
    {
        public Guid Id { get; set; }
        
    
    }
}
