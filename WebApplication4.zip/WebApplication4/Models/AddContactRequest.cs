namespace WebApplication4.Models;

public class AddContactRequest
{
    
}